debian@debian:~$ docker inspect eclipse-temurin:17-jre-jammy
[
    {
        "Id": "sha256:ac74f4849accb60e34a7942d51eaddc907f934677b8af4b6b59234fce5974a99",
        "RepoTags": [
            "eclipse-temurin:17-jre-jammy"
        ],
        "RepoDigests": [
            "eclipse-temurin@sha256:c1cd13b3cc4e0ec634dec367b3769131947201352ca290f5da7d373f6a620393"
        ],
        "Parent": "",
        "Comment": "buildkit.dockerfile.v0",
        "Created": "2024-04-23T20:51:38Z",
        "DockerVersion": "",
        "Author": "",
        "Config": {
            "Hostname": "",
            "Domainname": "",
            "User": "",
            "AttachStdin": false,
            "AttachStdout": false,
            "AttachStderr": false,
            "Tty": false,
            "OpenStdin": false,
            "StdinOnce": false,
            "Env": [
                "PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "JAVA_HOME=/opt/java/openjdk",
                "LANG=en_US.UTF-8",
                "LANGUAGE=en_US:en",
                "LC_ALL=en_US.UTF-8",
                "JAVA_VERSION=jdk-17.0.11+9"
            ],
            "Cmd": null,
            "Image": "",
            "Volumes": null,
            "WorkingDir": "",
            "Entrypoint": [
                "/__cacert_entrypoint.sh"
            ],
            "OnBuild": null,
            "Labels": {
                "org.opencontainers.image.ref.name": "ubuntu",
                "org.opencontainers.image.version": "22.04"
            }
        },
        "Architecture": "amd64",
        "Os": "linux",
        "Size": 254969074,
        "GraphDriver": {
            "Data": {
                "LowerDir": "/var/lib/docker/overlay2/e7e4f196aeae2b36c55db422ccbfbca0048b5b53f2148f9630851508ca09d7a2/diff:/var/lib/docker/overlay2/f34294c43757b8e17a4ec977187aa0c459e8662b9e210addd3a485b0851bab30/diff:/var/lib/docker/overlay2/f2967b24f37dbe045af762ce92284ba28d9de501727e62b7e20ad8bc0ee5a75d/diff:/var/lib/docker/overlay2/3c81a80d4b8a75417b43a50737ca58c9fc21251f2bc434c883032a53d256b29b/diff",
                "MergedDir": "/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/merged",
                "UpperDir": "/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/diff",
                "WorkDir": "/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/work"
            },
            "Name": "overlay2"
        },
        "RootFS": {
            "Type": "layers",
            "Layers": [
                "sha256:0b9c994b0484c0bc61f9de7c28a58745a504704254c5e8ed12349ebee3393a66",
                "sha256:5e75506f60a059374907f0187525e1026f90d713cc161ed065d34d0b1974dc44",
                "sha256:578d1d811705a32839c483717ae66da919fd315f4b4fec6e33fc134644846b7a",
                "sha256:b759cd4d563a1c3ed7e80f902742ada4ac8dd9547f999dc5b9c26cf853e9e9e7",
                "sha256:c5eda2440be9123039fe2a0b81948210ffab749711fd203a4bb42340366a125e"
            ]
        },
        "Metadata": {
            "LastTagTime": "0001-01-01T00:00:00Z"
        }
    }
]


$ vim Dockerfile
```Dockerfile
FROM eclipse-temurin:17-jre-jammy
CMD ["sh"]
```
debian@debian:~/sub2$ docker build -t temur .
[+] Building 0.2s (5/5) FINISHED                                                                                    ...
 => naming to docker.io/library/temur                                                                                                                                                   0.0s
debian@debian:~/sub2$ docker run -it --rm temur
exec /__cacert_entrypoint.sh: exec format error
debian@debian:~/sub2$ docker run -it --rm --entrypoint sh temur
# ls
bin  boot  __cacert_entrypoint.sh  dev	etc  home  lib	lib32  lib64  libx32  media  mnt  opt  proc  root  run	sbin  srv  sys	tmp  usr  var
# cat __cacert_entrypoint.sh
# ls -alg
total 56
drwxr-xr-x   1 root 4096 Jun 17 10:13 .
drwxr-xr-x   1 root 4096 Jun 17 10:13 ..
lrwxrwxrwx   1 root    7 May 30 02:03 bin -> usr/bin
drwxr-xr-x   2 root 4096 Apr 18  2022 boot
-rwxrwxr-x   1 root    0 Jun  5 04:54 __cacert_entrypoint.sh
drwxr-xr-x   5 root  360 Jun 17 10:13 dev
-rwxr-xr-x   1 root    0 Jun 17 10:13 .dockerenv
drwxr-xr-x   1 root 4096 Jun 17 10:13 etc
drwxr-xr-x   2 root 4096 Apr 18  2022 home
lrwxrwxrwx   1 root    7 May 30 02:03 lib -> usr/lib
lrwxrwxrwx   1 root    9 May 30 02:03 lib32 -> usr/lib32
lrwxrwxrwx   1 root    9 May 30 02:03 lib64 -> usr/lib64
lrwxrwxrwx   1 root   10 May 30 02:03 libx32 -> usr/libx32
drwxr-xr-x   2 root 4096 May 30 02:03 media
drwxr-xr-x   2 root 4096 May 30 02:03 mnt
drwxr-xr-x   1 root 4096 Jun  5 04:54 opt
dr-xr-xr-x 143 root    0 Jun 17 10:13 proc
drwx------   1 root 4096 Jun  5 04:54 root
drwxr-xr-x   5 root 4096 May 30 02:06 run
lrwxrwxrwx   1 root    8 May 30 02:03 sbin -> usr/sbin
drwxr-xr-x   2 root 4096 May 30 02:03 srv
dr-xr-xr-x  13 root    0 Jun 17 10:13 sys
drwxrwxrwt   1 root 4096 Jun  5 04:54 tmp
drwxr-xr-x   1 root 4096 May 30 02:03 usr
drwxr-xr-x   1 root 4096 May 30 02:06 var

# ^D



# http://www.wenchao.fit/?p=7975
# /__cacert_entrypoint.sh java -version
# OR ##### exec "java -version"
$ cat __cacert_entrypoint.sh
```sh
#!/usr/bin/env sh
# Converted to POSIX shell to avoid the need for bash in the image
 
set -e
 
# Opt-in is only activated if the environment variable is set
if [ -n "$USE_SYSTEM_CA_CERTS" ]; then
 
    # Copy certificates from /certificates to the system truststore, but only if the directory exists and is not empty.
    # The reason why this is not part of the opt-in is because it leaves open the option to mount certificates at the
    # system location, for whatever reason.
    if [ -d /certificates ] && [ -n "$(ls -A /certificates 2>/dev/null)" ]; then
        cp -a /certificates/* /usr/local/share/ca-certificates/
    fi
 
    CACERT="$JAVA_HOME/lib/security/cacerts"
 
    # JDK8 puts its JRE in a subdirectory
    if [ -f "$JAVA_HOME/jre/lib/security/cacerts" ]; then
        CACERT="$JAVA_HOME/jre/lib/security/cacerts"
    fi
 
    # OpenJDK images used to create a hook for `update-ca-certificates`. Since we are using an entrypoint anyway, we
    # might as well just generate the truststore and skip the hooks.
    update-ca-certificates
 
    trust extract --overwrite --format=java-cacerts --filter=ca-anchors --purpose=server-auth "$CACERT"
fi
 
exec "$@"
```