# 2024-06-16    10:09
=====================

**Sub-task 2**

This is the second sub-task. Our client wants us to start the best vet clinic application ever so everyone can be sure that their lovely pets are healthy and happy ^_^. But the team's got a totally screwed up environment. Let's fix it.

*General notes*:
1. There are some templates, that should be used to solve this task, located at /opt/docker/source/final-task-2/. Copy them to /opt/docker/final-task2 and use it as your working directory. Run *checkup-final2* in this directory as well.
2. Please, use .yml instead of .yaml extension for the compose file

*Environment description*:
+ Compose file called docker-compose.yml is used. It servers 2 containers, volumes and Petclinic network. The copy of this file should be in your working directory.
+ Petclinic application running in the container and accessible on 8080 port inside and outside the container. Container uses an image built from Dockerfile file. The copy of this file should be in your working directory.
+ Database engine running in a separate container and using hlebsur/mysql:8 image. This image contains a hint in its metadata.

*Acceptance criteria for the task*:
- Petclinic app is accessible from the browser on 8080 port.
- You can see doctors lists and be able to make view/change pet owners list
- Application container status is healthy for the whole lifecycle
- You can check DB image metadata for the hint.

*Some hints*:
* Check logs for your app container. Observing a beautiful healthy cat taking his regular nap on the logo means the application has started correctly, and you can try to reach it via the browser. But it doesn't actually mean that everything is working. Make sure you can view lists of clients, doctors and make/save changes to them.
* Pay attention to the java command passed in the Dockerfile.




# docker status --no -stream  Displays resource usage stats

./vmstart.sh

# doesn't work
# source .env && docker run -it --rm -p 3306:3306 --name hlebsur_mysql8 hlebsur/mysql:8 bash

cd /opt/do*/fi*2 ; ls -alg
docker compose build
docker compose up -d

 ✔ Network final-task-2_petclinic        Created                                     0.1s 
 ✔ Volume "final-task-2_mysql_data"      Creat...                                    0.0s 
 ✔ Volume "final-task-2_mysql_config"    Cre...                                      0.0s 
 ✔ Container final-task-2-mysqlserver-1  S...                                        0.4s 
 ✔ Container final-task-2-petclinic-1    Sta...                                      1.0s 
debian@debian:/opt/docker/final-task-2$ docker ps -a
CONTAINER ID   IMAGE                    COMMAND                  CREATED          STATUS                         PORTS                                                  NAMES
25ac48eef44d   final-task-2-petclinic   "/__cacert_entrypoin…"   37 seconds ago   Restarting (1) 4 seconds ago                                                          final-task-2-petclinic-1
69a8ee77c215   hlebsur/mysql:8          "docker-entrypoint.s…"   37 seconds ago   Up 36 seconds                  0.0.0.0:3306->3306/tcp, :::3306->3306/tcp, 33060/tcp   final-task-2-mysqlserver-1

source .env && docker exec -it final-task-2-mysqlserver-1 bash

debian@debian:/opt/docker/final-task-2$ source .env && docker exec -it final-task-2-mysqlserver-1 bash
bash-4.4# mysql -u petclinic -ppetclinic

mysql> SHOW DATABASES;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| performance_schema |
+--------------------+
2 rows in set (0.01 sec)

mysql> USE information_schema; SHOW tables;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
+---------------------------------------+
| Tables_in_information_schema          |
+---------------------------------------+
| ADMINISTRABLE_ROLE_AUTHORIZATIONS     |
| APPLICABLE_ROLES                      |
| CHARACTER_SETS                        |
    ...
| TABLES                                |
| TABLESPACES                           |
| TABLESPACES_EXTENSIONS                |
| TABLES_EXTENSIONS                     |
| TABLE_CONSTRAINTS                     |
| TABLE_CONSTRAINTS_EXTENSIONS          |
| TABLE_PRIVILEGES                      |
| TRIGGERS                              |
| USER_ATTRIBUTES                       |
| USER_PRIVILEGES                       |
| VIEWS                                 |
| VIEW_ROUTINE_USAGE                    |
| VIEW_TABLE_USAGE                      |
+---------------------------------------+
79 rows in set (0.02 sec)

mysql> USE information_schema; SELECT * FROM TABLE_CONSTRAINTS ;
Database changed
+--------------------+--------------------+-----------------+--------------------+-------------------------------+-----------------+----------+
| CONSTRAINT_CATALOG | CONSTRAINT_SCHEMA  | CONSTRAINT_NAME | TABLE_SCHEMA       | TABLE_NAME                    | CONSTRAINT_TYPE | ENFORCED |
+--------------------+--------------------+-----------------+--------------------+-------------------------------+-----------------+----------+
| def                | performance_schema | PRIMARY         | performance_schema | global_status                 | PRIMARY KEY     | YES      |
| def                | performance_schema | PRIMARY         | performance_schema | global_variables              | PRIMARY KEY     | YES      |
| def                | performance_schema | PRIMARY         | performance_schema | persisted_variables           | PRIMARY KEY     | YES      |
| def                | performance_schema | PRIMARY         | performance_schema | processlist                   | PRIMARY KEY     | YES      |
| def                | performance_schema | PRIMARY         | performance_schema | session_account_connect_attrs | PRIMARY KEY     | YES      |
| def                | performance_schema | PRIMARY         | performance_schema | session_status                | PRIMARY KEY     | YES      |
| def                | performance_schema | PRIMARY         | performance_schema | session_variables             | PRIMARY KEY     | YES      |
+--------------------+--------------------+-----------------+--------------------+-------------------------------+-----------------+----------+
7 rows in set (0.00 sec)

mysql> exit
\# exit

debian@debian:/opt/docker/final-task-2$ docker inspect final-task-2-petclinic-1
[
    {
        "Id": "25ac48eef44d4dff8097eac13c2fc1a8966d68361b36e165e61f5d51718059c1",
        "Created": "2024-06-16T08:49:54.776183157Z",
        "Path": "/__cacert_entrypoint.sh",
        "Args": [
            "/bin/sh",
            "-c",
            "[\"java\", \"-Djava.security.egd=file:/dev/./urandom\" \"-jar\", \"/spring-petclinic.jar\"]"
        ],
        "State": {
            "Status": "restarting",
            "Running": true,
            "Paused": false,
            "Restarting": true,
            "OOMKilled": false,
            "Dead": false,
            "Pid": 0,
            "ExitCode": 1,
            "Error": "",
            "StartedAt": "2024-06-16T08:58:46.78712928Z",
            "FinishedAt": "2024-06-16T08:58:47.026698496Z",
            "Health": {
                "Status": "unhealthy",
                "FailingStreak": 0,
                "Log": []
            }
        },
        "Image": "sha256:e5dc12459fbf2a0c1b4b8498fbdbfeb4eedfbdef8809e224f0b43b4f8070f68e",
        "ResolvConfPath": "/var/lib/docker/containers/25ac48eef44d4dff8097eac13c2fc1a8966d68361b36e165e61f5d51718059c1/resolv.conf",
        "HostnamePath": "/var/lib/docker/containers/25ac48eef44d4dff8097eac13c2fc1a8966d68361b36e165e61f5d51718059c1/hostname",
        "HostsPath": "/var/lib/docker/containers/25ac48eef44d4dff8097eac13c2fc1a8966d68361b36e165e61f5d51718059c1/hosts",
        "LogPath": "/var/lib/docker/containers/25ac48eef44d4dff8097eac13c2fc1a8966d68361b36e165e61f5d51718059c1/25ac48eef44d4dff8097eac13c2fc1a8966d68361b36e165e61f5d51718059c1-json.log",
        "Name": "/final-task-2-petclinic-1",
        "RestartCount": 18,
        "Driver": "overlay2",
        "Platform": "linux",
        "MountLabel": "",
        "ProcessLabel": "",
        "AppArmorProfile": "docker-default",
        "ExecIDs": null,
        "HostConfig": {
            "Binds": [
                "/opt/docker/final-task-2:/app:rw"
            ],
            "ContainerIDFile": "",
            "LogConfig": {
                "Type": "json-file",
                "Config": {}
            },
            "NetworkMode": "final-task-2_petclinic",
            "PortBindings": {
                "8000/tcp": [
                    {
                        "HostIp": "",
                        "HostPort": "8000"
                    }
                ],
                "8080/tcp": [
                    {
                        "HostIp": "",
                        "HostPort": "8082"
                    }
                ]
            },
            "RestartPolicy": {
                "Name": "unless-stopped",
                "MaximumRetryCount": 0
            },
            "AutoRemove": false,
            "VolumeDriver": "",
            "VolumesFrom": null,
            "ConsoleSize": [
                0,
                0
            ],
            "CapAdd": null,
            "CapDrop": null,
            "CgroupnsMode": "private",
            "Dns": null,
            "DnsOptions": null,
            "DnsSearch": null,
            "ExtraHosts": [],
            "GroupAdd": null,
            "IpcMode": "private",
            "Cgroup": "",
            "Links": null,
            "OomScoreAdj": 0,
            "PidMode": "",
            "Privileged": false,
            "PublishAllPorts": false,
            "ReadonlyRootfs": false,
            "SecurityOpt": null,
            "UTSMode": "",
            "UsernsMode": "",
            "ShmSize": 67108864,
            "Runtime": "runc",
            "Isolation": "",
            "CpuShares": 0,
            "Memory": 0,
            "NanoCpus": 0,
            "CgroupParent": "",
            "BlkioWeight": 0,
            "BlkioWeightDevice": null,
            "BlkioDeviceReadBps": null,
            "BlkioDeviceWriteBps": null,
            "BlkioDeviceReadIOps": null,
            "BlkioDeviceWriteIOps": null,
            "CpuPeriod": 0,
            "CpuQuota": 0,
            "CpuRealtimePeriod": 0,
            "CpuRealtimeRuntime": 0,
            "CpusetCpus": "",
            "CpusetMems": "",
            "Devices": null,
            "DeviceCgroupRules": null,
            "DeviceRequests": null,
            "MemoryReservation": 0,
            "MemorySwap": 0,
            "MemorySwappiness": null,
            "OomKillDisable": null,
            "PidsLimit": null,
            "Ulimits": null,
            "CpuCount": 0,
            "CpuPercent": 0,
            "IOMaximumIOps": 0,
            "IOMaximumBandwidth": 0,
            "MaskedPaths": [
                "/proc/asound",
                "/proc/acpi",
                "/proc/kcore",
                "/proc/keys",
                "/proc/latency_stats",
                "/proc/timer_list",
                "/proc/timer_stats",
                "/proc/sched_debug",
                "/proc/scsi",
                "/sys/firmware",
                "/sys/devices/virtual/powercap"
            ],
            "ReadonlyPaths": [
                "/proc/bus",
                "/proc/fs",
                "/proc/irq",
                "/proc/sys",
                "/proc/sysrq-trigger"
            ]
        },
        "GraphDriver": {
            "Data": {
                "LowerDir": "/var/lib/docker/overlay2/098b277f0080eeb585702485da9c664cfb33079861adcd158acaa076f1d466d2-init/diff:/var/lib/docker/overlay2/va1fz2ajcrogmh46okvt4rlhd/diff:/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/diff:/var/lib/docker/overlay2/e7e4f196aeae2b36c55db422ccbfbca0048b5b53f2148f9630851508ca09d7a2/diff:/var/lib/docker/overlay2/f34294c43757b8e17a4ec977187aa0c459e8662b9e210addd3a485b0851bab30/diff:/var/lib/docker/overlay2/f2967b24f37dbe045af762ce92284ba28d9de501727e62b7e20ad8bc0ee5a75d/diff:/var/lib/docker/overlay2/3c81a80d4b8a75417b43a50737ca58c9fc21251f2bc434c883032a53d256b29b/diff",
                "MergedDir": "/var/lib/docker/overlay2/098b277f0080eeb585702485da9c664cfb33079861adcd158acaa076f1d466d2/merged",
                "UpperDir": "/var/lib/docker/overlay2/098b277f0080eeb585702485da9c664cfb33079861adcd158acaa076f1d466d2/diff",
                "WorkDir": "/var/lib/docker/overlay2/098b277f0080eeb585702485da9c664cfb33079861adcd158acaa076f1d466d2/work"
            },
            "Name": "overlay2"
        },
        "Mounts": [
            {
                "Type": "bind",
                "Source": "/opt/docker/final-task-2",
                "Destination": "/app",
                "Mode": "rw",
                "RW": true,
                "Propagation": "rprivate"
            }
        ],
        "Config": {
            "Hostname": "25ac48eef44d",
            "Domainname": "",
            "User": "",
            "AttachStdin": false,
            "AttachStdout": true,
            "AttachStderr": true,
            "ExposedPorts": {
                "8000/tcp": {},
                "8080/tcp": {},
                "8081/tcp": {}
            },
            "Tty": false,
            "OpenStdin": false,
            "StdinOnce": false,
            "Env": [
                "SERVER_PORT=8080",
                "MYSQL_URL=jdbc:mysql://mysqlserver/petclinic",
                "PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "JAVA_HOME=/opt/java/openjdk",
                "LANG=en_US.UTF-8",
                "LANGUAGE=en_US:en",
                "LC_ALL=en_US.UTF-8",
                "JAVA_VERSION=jdk-17.0.11+9"
            ],
            "Cmd": [
                "/bin/sh",
                "-c",
                "[\"java\", \"-Djava.security.egd=file:/dev/./urandom\" \"-jar\", \"/spring-petclinic.jar\"]"
            ],
            "Healthcheck": {
                "Test": [
                    "CMD-SHELL",
                    "curl -f http://localhost:8082/ || exit 1"
                ],
                "StartPeriod": 60000000000
            },
            "Image": "final-task-2-petclinic",
            "Volumes": null,
            "WorkingDir": "",
            "Entrypoint": [
                "/__cacert_entrypoint.sh"
            ],
            "OnBuild": null,
            "Labels": {
                "com.docker.compose.config-hash": "1361aaa086138b947a485d232e62c974a9fe8f349279dab558a7aad720777376",
                "com.docker.compose.container-number": "1",
                "com.docker.compose.depends_on": "mysqlserver:service_started:false",
                "com.docker.compose.image": "sha256:e5dc12459fbf2a0c1b4b8498fbdbfeb4eedfbdef8809e224f0b43b4f8070f68e",
                "com.docker.compose.oneoff": "False",
                "com.docker.compose.project": "final-task-2",
                "com.docker.compose.project.config_files": "/opt/docker/final-task-2/docker-compose.yml",
                "com.docker.compose.project.working_dir": "/opt/docker/final-task-2",
                "com.docker.compose.service": "petclinic",
                "com.docker.compose.version": "2.27.0",
                "org.opencontainers.image.ref.name": "ubuntu",
                "org.opencontainers.image.version": "22.04"
            }
        },
        "NetworkSettings": {
            "Bridge": "",
            "SandboxID": "ace043b61ec64fefd094296f622c3ea44966134d08710724e886345d8e2394f0",
            "SandboxKey": "/var/run/docker/netns/ace043b61ec6",
            "Ports": {},
            "HairpinMode": false,
            "LinkLocalIPv6Address": "",
            "LinkLocalIPv6PrefixLen": 0,
            "SecondaryIPAddresses": null,
            "SecondaryIPv6Addresses": null,
            "EndpointID": "",
            "Gateway": "",
            "GlobalIPv6Address": "",
            "GlobalIPv6PrefixLen": 0,
            "IPAddress": "",
            "IPPrefixLen": 0,
            "IPv6Gateway": "",
            "MacAddress": "",
            "Networks": {
                "final-task-2_petclinic": {
                    "IPAMConfig": null,
                    "Links": null,
                    "Aliases": [
                        "final-task-2-petclinic-1",
                        "petclinic"
                    ],
                    "MacAddress": "",
                    "NetworkID": "71fb9000c11c445a462b3b5e1a0cdf6eb8131bb22cba786e00d39d62db15a3c7",
                    "EndpointID": "",
                    "Gateway": "",
                    "IPAddress": "",
                    "IPPrefixLen": 0,
                    "IPv6Gateway": "",
                    "GlobalIPv6Address": "",
                    "GlobalIPv6PrefixLen": 0,
                    "DriverOpts": null,
                    "DNSNames": [
                        "final-task-2-petclinic-1",
                        "petclinic",
                        "25ac48eef44d"
                    ]
                }
            }
        }
    }
]

debian@debian:/opt/docker/final-task-2$ docker compose up -d
[+] Running 3/3
 ✔ Network final-task-2_petclinic        Created                  0.1s 
 ✔ Container final-task-2-mysqlserver-1  Started                  0.4s 
 ✔ Container final-task-2-petclinic-1    Started                  1.1s 
debian@debian:/opt/docker/final-task-2$ docker compose config
name: final-task-2
services:
  mysqlserver:
    environment:
      MYSQL_ALLOW_EMPTY_PASSWORD: "true"
      MYSQL_DATABASE: ""
      MYSQL_PASSWORD: petclinic
      MYSQL_ROOT_PASSWORD: ""
      MYSQL_USER: petclinic
    image: hlebsur/mysql:8
    networks:
      petclinic: null
    ports:
      - mode: ingress
        target: 3306
        published: "3306"
        protocol: tcp
    restart: unless-stopped
    volumes:
      - type: volume
        source: mysql_data
        target: /var/lib/mysql
        volume: {}
      - type: volume
        source: mysql_config
        target: /etc/mysql/conf.d
        volume: {}
  petclinic:
    build:
      context: /opt/docker/final-task-2
      dockerfile: Dockerfile
    depends_on:
      mysqlserver:
        condition: service_started
        required: true
    environment:
      MYSQL_URL: jdbc:mysql://mysqlserver/petclinic
      SERVER_PORT: "8080"
    networks:
      petclinic: null
    ports:
      - mode: ingress
        target: 8000
        published: "8000"
        protocol: tcp
      - mode: ingress
        target: 8080
        published: "8080"
        protocol: tcp
    restart: unless-stopped
    volumes:
      - type: bind
        source: /opt/docker/final-task-2
        target: /app
        bind:
          create_host_path: true
networks:
  petclinic:
    name: final-task-2_petclinic
    driver: bridge
volumes:
  mysql_config:
    name: final-task-2_mysql_config
  mysql_data:
    name: final-task-2_mysql_data

$ docker inspect eclipse-temurin:17-jre-jammy
[
    {
        "Id": "sha256:ac74f4849accb60e34a7942d51eaddc907f934677b8af4b6b59234fce5974a99",
        "RepoTags": [
            "eclipse-temurin:17-jre-jammy"
        ],
        "RepoDigests": [
            "eclipse-temurin@sha256:c1cd13b3cc4e0ec634dec367b3769131947201352ca290f5da7d373f6a620393"
        ],
        "Parent": "",
        "Comment": "buildkit.dockerfile.v0",
        "Created": "2024-04-23T20:51:38Z",
        "DockerVersion": "",
        "Author": "",
        "Config": {
            "Hostname": "",
            "Domainname": "",
            "User": "",
            "AttachStdin": false,
            "AttachStdout": false,
            "AttachStderr": false,
            "Tty": false,
            "OpenStdin": false,
            "StdinOnce": false,
            "Env": [
                "PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "JAVA_HOME=/opt/java/openjdk",
                "LANG=en_US.UTF-8",
                "LANGUAGE=en_US:en",
                "LC_ALL=en_US.UTF-8",
                "JAVA_VERSION=jdk-17.0.11+9"
            ],
            "Cmd": null,
            "Image": "",
            "Volumes": null,
            "WorkingDir": "",
            "Entrypoint": [
                "/__cacert_entrypoint.sh"
            ],
            "OnBuild": null,
            "Labels": {
                "org.opencontainers.image.ref.name": "ubuntu",
                "org.opencontainers.image.version": "22.04"
            }
        },
        "Architecture": "amd64",
        "Os": "linux",
        "Size": 254969074,
        "GraphDriver": {
            "Data": {
                "LowerDir": "/var/lib/docker/overlay2/e7e4f196aeae2b36c55db422ccbfbca0048b5b53f2148f9630851508ca09d7a2/diff:/var/lib/docker/overlay2/f34294c43757b8e17a4ec977187aa0c459e8662b9e210addd3a485b0851bab30/diff:/var/lib/docker/overlay2/f2967b24f37dbe045af762ce92284ba28d9de501727e62b7e20ad8bc0ee5a75d/diff:/var/lib/docker/overlay2/3c81a80d4b8a75417b43a50737ca58c9fc21251f2bc434c883032a53d256b29b/diff",
                "MergedDir": "/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/merged",
                "UpperDir": "/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/diff",
                "WorkDir": "/var/lib/docker/overlay2/6c0e64e9ad045e6d4fc68337dc9f90839d6c213f04eaaa44ca2908ab8aa86c64/work"
            },
            "Name": "overlay2"
        },
        "RootFS": {
            "Type": "layers",
            "Layers": [
                "sha256:0b9c994b0484c0bc61f9de7c28a58745a504704254c5e8ed12349ebee3393a66",
                "sha256:5e75506f60a059374907f0187525e1026f90d713cc161ed065d34d0b1974dc44",
                "sha256:578d1d811705a32839c483717ae66da919fd315f4b4fec6e33fc134644846b7a",
                "sha256:b759cd4d563a1c3ed7e80f902742ada4ac8dd9547f999dc5b9c26cf853e9e9e7",
                "sha256:c5eda2440be9123039fe2a0b81948210ffab749711fd203a4bb42340366a125e"
            ]
        },
        "Metadata": {
            "LastTagTime": "0001-01-01T00:00:00Z"
        }
    }
]

$ docker inspect hlebsur/pet_clinic_not_full:latest
[
    {
        "Id": "sha256:72f2d5a6863905bd0faf7411aa3f58d747521d40a7c32db150d1a2426db9b000",
        "RepoTags": [
            "hlebsur/pet_clinic_not_full:latest"
        ],
        "RepoDigests": [
            "hlebsur/pet_clinic_not_full@sha256:88589628af744d15a2fe9634b4f1cc8e7f8a99d5c8764dd287e647c6229c74f0"
        ],
        "Parent": "",
        "Comment": "buildkit.dockerfile.v0",
        "Created": "2023-01-04T19:29:51.175336987Z",
        "DockerVersion": "",
        "Author": "",
        "Config": {
            "Hostname": "",
            "Domainname": "",
            "User": "",
            "AttachStdin": false,
            "AttachStdout": false,
            "AttachStderr": false,
            "Tty": false,
            "OpenStdin": false,
            "StdinOnce": false,
            "Env": [
                "PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "JAVA_HOME=/opt/java/openjdk",
                "LANG=en_US.UTF-8",
                "LANGUAGE=en_US:en",
                "LC_ALL=en_US.UTF-8",
                "JAVA_VERSION=jdk-17.0.5+8"
            ],
            "Cmd": [
                "jshell"
            ],
            "Image": "",
            "Volumes": null,
            "WorkingDir": "/app",
            "Entrypoint": null,
            "OnBuild": null,
            "Labels": null
        },
        "Architecture": "amd64",
        "Os": "linux",
        "Size": 680029261,
        "GraphDriver": {
            "Data": {
                "LowerDir": "/var/lib/docker/overlay2/5418d56746f8d7d4b7ab319c1f789e4844a17feafecb5d8ef2352e934d3e1ae2/diff:/var/lib/docker/overlay2/8147f7e2c967d761c8ef578032511c869d48682d807601e52e144dbb6084d22d/diff:/var/lib/docker/overlay2/38bd77e4647a9fc551d860ae1e48f38d7d49448513ff9a15e380ce72c196fdfc/diff:/var/lib/docker/overlay2/581317d5e5056ec4e522e3951778fde8f96b6a9670c8d0fe0948a8a3b417d900/diff:/var/lib/docker/overlay2/1ab5347e4af1ffa4c0721cc50fc443d88a805e59982cf15b7c337df49356a05a/diff:/var/lib/docker/overlay2/193dad8e2ab1ce11bd179a0e272da2ba989435d2db2eec82a6766b6c4d37668a/diff:/var/lib/docker/overlay2/b230cdca80bf4f8210b11c36d9aba7a50931aebfce6c3c4415b84b22319371f8/diff:/var/lib/docker/overlay2/a182f205729728e7990d46dbd6b21856c815ee04312fe7ab39670da1585473fd/diff:/var/lib/docker/overlay2/8df33d744636beb6643b36f9d750fc1cb8f5d6ef72e281f782fbcbdb562ea303/diff",
                "MergedDir": "/var/lib/docker/overlay2/69f743bc64973722a543a9d4b6fc7677a1838ee0256a7bbe55d201c75b54907f/merged",
                "UpperDir": "/var/lib/docker/overlay2/69f743bc64973722a543a9d4b6fc7677a1838ee0256a7bbe55d201c75b54907f/diff",
                "WorkDir": "/var/lib/docker/overlay2/69f743bc64973722a543a9d4b6fc7677a1838ee0256a7bbe55d201c75b54907f/work"
            },
            "Name": "overlay2"
        },
        "RootFS": {
            "Type": "layers",
            "Layers": [
                "sha256:6515074984c6f8bb1b8a9962c8fb5f310fc85e70b04c88442a3939c026dbfad3",
                "sha256:86c081974855f765ab2e3eb92719dfaf8ff69e32af9ec317ce03e8ef7583f8b8",
                "sha256:cd7884686c9fc94d950cd066744c73da12badfbf6643f8cf9a95a23dd5c28194",
                "sha256:f52b91b1b5b3f0bf0bc7cde4ef1682c7349293cdad64129d365e7ef01a23169b",
                "sha256:13e924a7e348cb0c63f30905806d0c4f2387cec292d31f66459b25046ffabbb8",
                "sha256:7a5d765f9807f8de278cad823274c573f892649097da68576e24f1fb5e103d47",
                "sha256:3455071d43a799f4058e790b8ba36ee78279692a3fac20431b33644c3b42bc6a",
                "sha256:47e25b14e585cdb024fb9684de241186fae4bd8f634b3f4ecec42b6f65e7da10",
                "sha256:6a3889aebee7ddec3cc731f18a122be03457fc6085df3a805a159486dfca6dbf",
                "sha256:014750f8f54946a8a13a6d5cef97ccf38ba216a3e53c132cd072aa1c6b1325f0"
            ]
        },
        "Metadata": {
            "LastTagTime": "0001-01-01T00:00:00Z"
        }
    }
]
