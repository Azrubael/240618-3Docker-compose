debian@debian:~/sub2$ docker pull eclipse-temurin:11-jre-jammy
11-jre-jammy: Pulling from library/eclipse-temurin
Digest: sha256:cf907ea034865e948b0ca69e85a9209624b2948a044401c252df3ef3037dda0c
Status: Image is up to date for eclipse-temurin:11-jre-jammy
docker.io/library/eclipse-temurin:11-jre-jammy



debian@debian:~/sub2$ docker build -t temur11 -f Dockerfile_11 .
[+] Building 0.1s (5/5) FINISHED                            docker:default
 => [internal] load build definition from Dockerfile_11
    ...
 => => naming to docker.io/library/temur11                  0.0s
debian@debian:~/sub2$ run -it --rm --entrypoint sh temur11
-bash: run: command not found
debian@debian:~/sub2$ docker run -it --rm --entrypoint sh temur11
\# cat __cacert_entrypoint.sh
#!/usr/bin/env bash
# Sheband needs to be `bash`, see https://github.com/adoptium/containers/issues/415 for details

set -e

# Opt-in is only activated if the environment variable is set
if [ -n "$USE_SYSTEM_CA_CERTS" ]; then

    # Copy certificates from /certificates to the system truststore, but only if the directory exists and is not empty.
    # The reason why this is not part of the opt-in is because it leaves open the option to mount certificates at the
    # system location, for whatever reason.
    if [ -d /certificates ] && [ "$(ls -A /certificates)" ]; then
        cp -a /certificates/* /usr/local/share/ca-certificates/
    fi

    CACERT=$JAVA_HOME/lib/security/cacerts

    # JDK8 puts its JRE in a subdirectory
    if [ -f "$JAVA_HOME/jre/lib/security/cacerts" ]; then
        CACERT=$JAVA_HOME/jre/lib/security/cacerts
    fi

    # OpenJDK images used to create a hook for `update-ca-certificates`. Since we are using an entrypoint anyway, we
    # might as well just generate the truststore and skip the hooks.
    update-ca-certificates

    trust extract --overwrite --format=java-cacerts --filter=ca-anchors --purpose=server-auth "$CACERT"
fi

exec "$@"
\# exit
debian@debian:~/sub2$ 
