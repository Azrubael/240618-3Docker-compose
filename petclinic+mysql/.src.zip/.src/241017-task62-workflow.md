# 2024-06-17    08:54
=====================

docker run --rm --name petcli -d -v $(pwd)/petclinic:/app/backup hlebsur/pet_clinic_not_full:latest bash -c "sleep infinity"
docker exec -it petcli bash

root@ad35c5f6cb6c:/app# ls
backup  mvnw  pom.xml  src  target

root@ad35c5f6cb6c:/app# ls target
checkstyle-cachefile    checkstyle-suppressions.xml  generated-test-sources
maven-status            spring-petclinic-2.7.0-SNAPSHOT.jar.original
checkstyle-checker.xml  classes                      jacoco.exec             site                    surefire-reports             checkstyle-result.xml
generated-sources       maven-archiver               spring-petclinic-2.7.0-SNAPSHOT.jar  test-classes

root@ad35c5f6cb6c:/app# cp target/spring-petclinic-2.7.0-SNAPSHOT.jar backup/spring-pet.jar
root@ad35c5f6cb6c:/app# exit
exit



# OR
root@114add4e1204:/app# apt install maven -y

root@114add4e1204:/app# mvn -version
Apache Maven 3.6.3
Maven home: /usr/share/maven
Java version: 17.0.5, vendor: Eclipse Adoptium, runtime: /opt/java/openjdk
Default locale: en_US, platform encoding: UTF-8
OS name: "linux", version: "5.10.0-20-amd64", arch: "amd64", family: "unix"

root@114add4e1204:/app# mvn install
...

              |\      _,,,--,,_
             /,`.-'`'   ._  \-;;,_
  _______ __|,4-  ) )_   .;.(__`'-'__     ___ __    _ ___ _______
 |       | '---''(_/._)-'(_\_)   |   |   |   |  |  | |   |       |
 |    _  |    ___|_     _|       |   |   |   |   |_| |   |       | __ _ _
 |   |_| |   |___  |   | |       |   |   |   |       |   |       | \ \ \ \
 |    ___|    ___| |   | |      _|   |___|   |  _    |   |      _|  \ \ \ \
 |   |   |   |___  |   | |     |_|       |   | | |   |   |     |_    ) ) ) )
 |___|   |_______| |___| |_______|_______|___|_|  |__|___|_______|  / / / /
 ==================================================================/_/_/_/

:: Built with Spring Boot :: 2.7.1

...

docker build -t petclinic .
docker run --rm --name petcli -it petclinic:latest sh
docker exec -it petcli bash

$ vim Dockerfile_temurin
```Dockerfile
FROM eclipse-temurin:17-jre-jammy
COPY ./petclinic/spring-pet.jar /spring-petclinic.jar
CMD ["java", "-Djava.security.egd=file:/dev/./urandom", "-jar", "/spring-petclinic.jar"]
```

docker build -t temurin -f Dockerfile_temurin .
docker run --name temur -it temurin:latest bash


debian@debian:/opt/docker/final-task2$ docker container ls -a
CONTAINER ID   IMAGE                   COMMAND                  CREATED          STATUS                    PORTS                                                  NAMES
a437ec713fd0   final-task2-petclinic   "java -Djava.securit…"   43 seconds ago   Up 41 seconds (healthy)   0.0.0.0:8080->8080/tcp, :::8080->8080/tcp              final-task2-petclinic-1
3ddd998a13b6   hlebsur/mysql:8         "docker-entrypoint.s…"   43 seconds ago   Up 42 seconds             0.0.0.0:3306->3306/tcp, :::3306->3306/tcp, 33060/tcp   final-task2-mysqlserver-1
debian@debian:/opt/docker/final-task2$ checkup-final2
[ Final check. Checking if containers are OK ], 1..9 tests
-----------------------------------------------------------------------------------
✓  1  Checking exposed ports, 7ms, secret phrase: ""
✓  2  Checking healthcheck row, 7ms, secret phrase: ""
✓  3  Checking port mapping, 7ms, secret phrase: ""
✓  4  Check environment vars, 5ms, secret phrase: ""
✓  5  Check db volumes, 5ms, secret phrase: ""
✓  6  Check networking, 8ms, secret phrase: ""
✓  7  Checking app container is running and healthy, 25ms, secret phrase: ""
✓  8  Checking db container is running and healthy, 24ms, secret phrase: ""
✓  9  Final check: petclinic app is available, 243ms, secret phrase: "ohtoocojah4Pha"
-----------------------------------------------------------------------------------
9 (of 9) tests passed, 0 tests failed, rated as 100.00%, spent 340ms


debian@debian:/opt/docker/final-task2$ docker compose config
name: final-task2
services:
  mysqlserver:
    environment:
      MYSQL_ALLOW_EMPTY_PASSWORD: "true"
      MYSQL_DATABASE: information_schema
      MYSQL_PASSWORD: petclinic
      MYSQL_ROOT_PASSWORD: ""
      MYSQL_USER: petclinic
    image: hlebsur/mysql:8
    networks:
      petclinic: null
    ports:
      - mode: ingress
        target: 3306
        published: "3306"
        protocol: tcp
    restart: unless-stopped
    volumes:
      - type: volume
        source: mysql_data
        target: /var/lib/mysql
        volume: {}
      - type: volume
        source: mysql_config
        target: /etc/mysql/conf.d
        volume: {}
  petclinic:
    build:
      context: /opt/docker/final-task2
      dockerfile: Dockerfile
    depends_on:
      mysqlserver:
        condition: service_started
        required: true
    environment:
      MYSQL_PASSWORD: petclinic
      MYSQL_URL: jdbc:mysql://mysqlserver/petclinic
      MYSQL_USER: petclinic
      SERVER_PORT: "8080"
    networks:
      petclinic: null
    ports:
      - mode: ingress
        target: 8080
        published: "8080"
        protocol: tcp
    restart: unless-stopped
    volumes:
      - type: bind
        source: /opt/docker/final-task2
        target: /app
        bind:
          create_host_path: true
networks:
  petclinic:
    name: final-task2_petclinic
    driver: bridge
volumes:
  mysql_config:
    name: final-task2_mysql_config
  mysql_data:
    name: final-task2_mysql_data


